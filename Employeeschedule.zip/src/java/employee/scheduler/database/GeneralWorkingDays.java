/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package employee.scheduler.database;

/**
 *
 * @author Dotmons
 */
public class GeneralWorkingDays {

    String genWeekday;
    String genCapacity;

    public String getGenWeekday() {
        return genWeekday;
    }

    public void setGenWeekday(String genWeekday) {
        this.genWeekday = genWeekday;
    }

    public String getGenCapacity() {
        return genCapacity;
    }

    public void setGenCapacity(String genCapacity) {
        this.genCapacity = genCapacity;
    }

}
