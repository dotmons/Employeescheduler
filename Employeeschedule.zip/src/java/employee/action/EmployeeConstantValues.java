/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package employee.action;

/**
 *
 * @author Dotmons
 */
public final class EmployeeConstantValues {
    
    
    public static final String tableMessage = "internalmessage";
    public static final String emailaddress = "";
    public static final String tableDepartment = "department";
    public static final String tableDetails = "employeedetails";
    public static final String tableLogin = "employeelogin";
    
    public static final String tableTimeday = "timeday";
    public static final String tableShiftresources = "shiftresources";
    public static final String tableWorkingdays = "workingdays";
    
    public static final String fieldColumnUsername = "username";
    
    
}
